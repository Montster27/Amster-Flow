// Re-export the useAuth hook from AuthContext for convenience
export { useAuth } from '../contexts/AuthContext';
