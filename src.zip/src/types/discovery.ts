// Customer Discovery Module Type Definitions

export type AssumptionType = 'customer' | 'problem' | 'solution';
export type AssumptionStatus = 'untested' | 'testing' | 'validated' | 'invalidated';
export type InterviewFormat = 'in-person' | 'phone' | 'video' | 'survey';
export type IntervieweeType = 'potential-buyer' | 'competitor' | 'substitute' | 'knowledgeable';
export type ConfidenceLevel = 1 | 2 | 3 | 4 | 5; // 1=very low, 5=very high

export interface Assumption {
  id: string;
  type: AssumptionType;
  description: string;
  created: string; // ISO date string
  lastUpdated: string; // ISO date string
  status: AssumptionStatus;
  confidence: ConfidenceLevel;
  evidence: string[]; // Array of notes or links to interviews
  linkedModule?: string; // e.g., "problem", "customerSegments", "solution"
  linkedQuestionIndex?: number;
  validationNotes?: string;
}

export interface Interview {
  id: string;
  date: string; // ISO date string
  customerSegment: string;
  interviewee?: string;
  intervieweeType?: IntervieweeType; // Type of person being interviewed
  format: InterviewFormat;
  duration?: number; // minutes
  notes: string;
  assumptionsAddressed: string[]; // Array of assumption IDs
  keyInsights: string[];
  surprises?: string;
  nextAction?: string;
  followUpNeeded: boolean;
}

export interface Iteration {
  id: string;
  date: string; // ISO date string
  version: number;
  changes: string;
  reasoning: string;
  assumptionsAffected: string[]; // Array of assumption IDs
  patternsObserved?: string;
  riskiestAssumption?: string; // assumption ID
  nextExperiment?: string;
}

export interface AssumptionTemplate {
  type: AssumptionType;
  prompts: string[];
}

export interface InterviewTemplate {
  category: string;
  questions: string[];
}

// ============================================================================
// ENHANCED INTERVIEW SYSTEM (New Structured Approach)
// ============================================================================

export type IntervieweeTypeEnhanced = 'customer' | 'partner' | 'regulator' | 'expert' | 'other';
export type ValidationEffect = 'supports' | 'contradicts' | 'neutral';
export type InterviewStatus = 'draft' | 'completed';

// Enhanced Assumption with additional tracking fields
export interface EnhancedAssumption extends Assumption {
  category: 'problem' | 'solution' | 'customer' | 'price' | 'channel';
  evidenceCount: number;
  supportingCount: number;
  contradictingCount: number;
  lastInterviewDate?: string;
}

// Tag linking interview insights to assumptions
export interface AssumptionTag {
  assumptionId: string;
  validationEffect: ValidationEffect;
  confidenceChange: number; // -2 to +2
  quote?: string; // Optional supporting quote
}

// Enhanced Interview with structured fields
export interface EnhancedInterview {
  id: string;

  // Metadata
  intervieweeType: IntervieweeTypeEnhanced;
  segmentName: string;
  date: string; // ISO date string
  context: string;
  status: InterviewStatus;

  // Key Findings
  mainPainPoints: string;
  problemImportance: ConfidenceLevel; // 1-5 Likert scale
  problemImportanceQuote?: string;
  currentAlternatives: string;
  memorableQuotes: string[];
  surprisingFeedback: string;

  // Assumption Tags
  assumptionTags: AssumptionTag[];

  // Reflection
  studentReflection: string;
  mentorFeedback?: string;

  // System fields
  created: string; // ISO date string
  lastUpdated: string;
}

// Synthesis result from multiple interviews
export interface InterviewSynthesis {
  interviewIds: string[];
  dateRange: {
    start: string;
    end: string;
  };
  patterns: {
    mostMentionedPainPoint: string;
    mostInvalidatedAssumption?: string;
    mostDiscussedSegments: string[];
  };
  assumptionSummaries: {
    assumptionId: string;
    supportingEvidence: string[];
    contradictingEvidence: string[];
    netEffect: ValidationEffect;
  }[];
}
